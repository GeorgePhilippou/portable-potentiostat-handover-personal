# Python dashboard — run on the computer

This is the shared dashboard for OCP, chronoamperometry, amperometry, CV/LSV and experimental EIS. It is editable Python source.

1. Python must already be installed (tested with 3.11); Spyder is optional. If needed, follow the installation guide: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/INSTALL_SOFTWARE.md
2. Extract this ZIP and open a terminal in the extracted Python_Dashboard folder.
3. Install dependencies with: python -m pip install -r requirements.txt
4. Run: python potentiostat_dashboard.py
   Alternatively open that file in Spyder using the same Python environment.
5. Close other serial readers, then Detect and open. The launcher identifies the flashed firmware; CV and LSV share a firmware image and you choose their mode in the launcher.

The matching firmware ZIP must be built/flashed in Code Composer Studio first. Keep ec_dashboard.py and dashboard_assets alongside the launcher; do not move the launcher by itself.

Matched download set: 503627896231aef9. PACKAGE.json identifies the set and exact source hashes. No firmware code is contained in this dashboard ZIP.
Setup and wiring: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/START_HERE.md
Windows drivers and CCS: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/WINDOWS_SETUP.md
Customisation: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/CUSTOMISATION.md
EIS remains in development.
