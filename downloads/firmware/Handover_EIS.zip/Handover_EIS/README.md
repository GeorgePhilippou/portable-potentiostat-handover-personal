# Handover_EIS — firmware source

This ZIP is the complete CCS firmware source project, not a pre-flashed binary.

Before starting: install CCS with MSP430 support and Python if needed. Installation guide: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/INSTALL_SOFTWARE.md

1. Extract the ZIP to a local folder.
2. Open CCS. In classic CCS use Project → Import CCS Projects; in newer CCS use File → Import Project(s). Select the extracted Handover_EIS folder and finish importing it.
3. Select the project and Build. When the build succeeds, use the CCS programming/debug action to load it through the MSP-FET. If debugging pauses at main, press Resume/Continue to run the firmware.
4. On the computer, extract the separate Python_Dashboard.zip and run its potentiostat_dashboard.py. Install its requirements.txt first.

Hardware configuration is in main.c. Toolchain used: TI MSP430 compiler 21.6.1.LTS. CV and LSV share Handover_CyclicVoltammetry; choose the mode in Python.

Windows drivers and project import: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/WINDOWS_SETUP.md
Connections: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/HARDWARE.md
Customisation: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/CUSTOMISATION.md

Matched download set: 503627896231aef9. Download firmware and Python from the same downloads page. PACKAGE.json identifies the set and included source hashes.

EIS IS IN DEVELOPMENT. This source is experimental; see the repository validation/EIS notes before use.
