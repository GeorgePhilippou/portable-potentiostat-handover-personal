# Handover_Chronoamperometric — firmware source

This ZIP is the complete CCS firmware source project, not a pre-flashed binary.

1. Extract the ZIP to a local folder.
2. In classic Code Composer Studio 12.5, use Project → Import CCS Projects and select this Handover_Chronoamperometric folder.
3. Select the project, Build, then use your usual Flash action with the TI MSP-FET and MSP430FR5994 board.
4. On the computer, extract the separate Python_Dashboard.zip and run its potentiostat_dashboard.py. Install its requirements.txt first.

Hardware configuration is in main.c. Toolchain used: TI MSP430 compiler 21.6.1.LTS. CV and LSV share Handover_CyclicVoltammetry; choose the mode in Python.

Connections: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/HARDWARE.md
Customisation: https://github.com/GeorgePhilippou/portable-potentiostat-handover-personal/blob/main/docs/CUSTOMISATION.md

Matched download set: 503627896231aef9. Download firmware and Python from the same downloads page. PACKAGE.json identifies the set and included source hashes.
